/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weather;
import java.sql.*;
import javax.swing.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Akhil
 */
public class Main {
    public Main() {
    
    }
    
public static void main(String[] args) {
        // TODO code application logic here
        try{ 
        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
        }catch(ClassNotFoundException e){
            System.out.println(e);
        }
        
        try{
        Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/stats", "zeus", "zeus");
        Statement stmt = con.createStatement();
        
        ResultSet rs = stmt.executeQuery("SELECT * FROM DEMO.Table1");
        
        while (rs.next()) {
        String s = rs.getString("Name");
        float n = rs.getFloat("Age");
        System.out.println(s + "   " + n);
    }
        }catch(SQLException e){
            System.err.println(e);
        }                 
     
      }

}
