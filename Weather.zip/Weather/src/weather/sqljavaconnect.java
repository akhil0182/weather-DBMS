/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weather;
import java.sql.*;
import javax.swing.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Akhil
 */
public class sqljavaconnect {
    Connection conn=null;
    public static Connection ConnectDB(){
        try{
            
            //DriverManager.registerDriver(apache_derby_net);
            Class.forName("apache_derby_net").newInstance();
            Connection conn=DriverManager.getConnection("jdbc:derby://localhost:1527/myDB;create=true;user=zeus;password=ZEUS");
            return conn;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
           return null;
        }
    
    }

   public static void main(String args[])
{
      // log l=new log();
      // l.setVisible(true);
   
}
}